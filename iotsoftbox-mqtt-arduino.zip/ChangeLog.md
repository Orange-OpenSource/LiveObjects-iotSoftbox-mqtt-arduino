# Change Log

## 1.2.0 (Jul 21, 2017)

**Implemented enhancements:**

- **Changed the way the [APIKEY](README.md#api-key) is filled**

## 1.1.0 (July 17, 2017)

**Implemented enhancements:**

- Updated doc
- Updated core to the last version
- Updated to MbedTLS 2.1.6
- Removed Support from Arduino Mega

**Fixed issues:**

- Replaced old certificate
- Fixed Data structure in examples

## 1.0.0 (Jan 27, 2017)

**First delivery**
