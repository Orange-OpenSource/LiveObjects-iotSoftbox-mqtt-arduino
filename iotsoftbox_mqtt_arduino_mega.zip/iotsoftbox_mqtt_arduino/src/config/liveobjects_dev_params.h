/*
 * Copyright (C) 2016 Orange
 *
 * This software is distributed under the terms and conditions of the 'BSD-3-Clause'
 * license which can be found in the file 'LICENSE.txt' in this package distribution
 * or at 'https://opensource.org/licenses/BSD-3-Clause'.
 *
 * This file is a part of LiveObjects iotsoftbox-mqtt library.
 */

/**
 * @file  liveobjects_dev_params.h
 * @brief Default user parameters used to configure this device as a Live Objects Device
 */

#ifndef __liveobjects_dev_params_H_
#define __liveobjects_dev_params_H_

// Set to 1 to enable TLS feature
// (warning: check that LOC_SERV_PORT is the correct port in this case)
#if defined(ARDUINO_ARCH_AVR)
#define SECURITY_ENABLED                     0
#else
#define SECURITY_ENABLED                     1
#endif

// Only used to overwrite the LiveOjects Server settings :
// IP address, TCP port, Connection timeout in milliseconds.
//#define LOC_SERV_IP_ADDRESS                  "XXXX"
//#define LOC_SERV_PORT                        XXXX
//#define LOC_SERV_TIMEOUT                     XXXX

// When there is an issue with DNS to resolve FQDN liveobjects.orange-business.com ?
//#define LOC_SERV_IP_ADDRESS                  "84.39.42.214"
#define LOC_SERV_IP_ADDRESS                  "84.39.42.208"

// When set to 1, use the MAC address as LiveObject device identifier
// otherwise use LOC_CLIENT_DEV_ID
#define LOC_CLIENT_USE_MAC_ADDR              0

// Default LiveObjects device settings : name space and device identifier
#define LOC_CLIENT_DEV_NAME_SPACE            "LiveObjectsSample"
#if !LOC_CLIENT_USE_MAC_ADDR
#if defined(ARDUINO_ARCH_AVR)
#define LOC_CLIENT_DEV_ID                    "LO_mega_adk_dev01"
#else
#define LOC_CLIENT_DEV_ID                    "LO_mediatek_dev01"
#endif
#endif

// Here, set your LiveObject Apikey. It is mandatory to run the application
#define LOC_CLIENT_DEV_API_KEY               "XXXX"

#if SECURITY_ENABLED
// If security is enabled to establish connection to the LiveObjects platform,
// include certificates file
#include "liveobjects_dev_security.h"
#endif

#endif //__liveobjects_dev_params_H_
